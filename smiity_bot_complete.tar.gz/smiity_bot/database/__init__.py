"""
Module de base de données pour Smiity Bot
"""

from .database import Database

__all__ = ['Database']

