"""
Module de configuration pour Smiity Bot
Commande /config avec embeds comme DraftBot
"""

import discord
from discord.ext import commands
from discord import app_commands
from typing import Optional, Dict, Any

from utils.embeds import EmbedBuilder

class ConfigCog(commands.Cog):
    """Cog pour la gestion de la configuration du bot"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="config", description="Affiche ou modifie la configuration du bot")
    @app_commands.describe(
        action="Action à effectuer (show, set, reset)",
        module="Module à configurer",
        setting="Paramètre à modifier",
        value="Nouvelle valeur"
    )
    @app_commands.choices(action=[
        app_commands.Choice(name="Afficher", value="show"),
        app_commands.Choice(name="Modifier", value="set"),
        app_commands.Choice(name="Réinitialiser", value="reset")
    ])
    @app_commands.choices(module=[
        app_commands.Choice(name="Modération", value="moderation"),
        app_commands.Choice(name="Niveaux", value="levels"),
        app_commands.Choice(name="Économie", value="economy"),
        app_commands.Choice(name="Bienvenue", value="welcome"),
        app_commands.Choice(name="Logs", value="logs"),
        app_commands.Choice(name="Auto-Mod", value="automod")
    ])
    async def config(
        self,
        interaction: discord.Interaction,
        action: str = "show",
        module: Optional[str] = None,
        setting: Optional[str] = None,
        value: Optional[str] = None
    ):
        """Commande principale de configuration"""
        
        # Vérification des permissions
        if not interaction.user.guild_permissions.manage_guild:
            embed = EmbedBuilder.error(
                "Permission refusée",
                "Vous devez avoir la permission **Gérer le serveur** pour utiliser cette commande."
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        guild_id = interaction.guild.id
        
        if action == "show":
            await self._show_config(interaction, guild_id)
        elif action == "set":
            if not module or not setting or not value:
                embed = EmbedBuilder.error(
                    "Paramètres manquants",
                    "Pour modifier un paramètre, vous devez spécifier le module, le paramètre et la valeur."
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            await self._set_config(interaction, guild_id, module, setting, value)
        elif action == "reset":
            await self._reset_config(interaction, guild_id, module)
    
    async def _show_config(self, interaction: discord.Interaction, guild_id: int):
        """Affiche la configuration actuelle"""
        
        # Récupération de la configuration depuis la base de données
        guild_config = await self.bot.db.get_guild(guild_id)
        
        if not guild_config:
            # Création de la configuration par défaut
            guild_config = await self.bot.db.create_guild(guild_id, interaction.guild.name)
        
        # Préparation des données pour l'embed
        config_data = {
            'modules': {
                'modération': guild_config.moderation_enabled,
                'niveaux': guild_config.levels_enabled,
                'économie': guild_config.economy_enabled,
                'bienvenue': guild_config.welcome_enabled,
                'logs': guild_config.logs_enabled
            },
            'channels': {
                'bienvenue': guild_config.welcome_channel_id,
                'logs': guild_config.logs_channel_id
            },
            'roles': {
                'modérateur': guild_config.moderator_role_id,
                'muet': guild_config.muted_role_id
            }
        }
        
        # Création de l'embed de configuration
        embed = EmbedBuilder.config(interaction.guild.name, config_data)
        
        # Ajout d'informations supplémentaires
        embed.add_field(
            name="🔧 Commandes utiles",
            value=(
                "`/config set moderation enabled true` - Activer la modération\n"
                "`/config set welcome channel #général` - Définir le canal de bienvenue\n"
                "`/config set logs channel #logs` - Définir le canal de logs"
            ),
            inline=False
        )
        
        await interaction.response.send_message(embed=embed)
    
    async def _set_config(self, interaction: discord.Interaction, guild_id: int, module: str, setting: str, value: str):
        """Modifie un paramètre de configuration"""
        
        try:
            # Récupération de la configuration
            guild_config = await self.bot.db.get_guild(guild_id)
            if not guild_config:
                guild_config = await self.bot.db.create_guild(guild_id, interaction.guild.name)
            
            # Traitement selon le module et le paramètre
            success = await self._process_config_change(guild_config, module, setting, value, interaction)
            
            if success:
                # Sauvegarde en base de données
                async with self.bot.db.get_session() as session:
                    session.add(guild_config)
                    await session.commit()
                
                embed = EmbedBuilder.success(
                    "Configuration mise à jour",
                    f"Le paramètre **{setting}** du module **{module}** a été modifié avec succès."
                )
            else:
                embed = EmbedBuilder.error(
                    "Erreur de configuration",
                    "Impossible de modifier ce paramètre. Vérifiez les valeurs fournies."
                )
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
        except Exception as e:
            embed = EmbedBuilder.error(
                "Erreur",
                f"Une erreur s'est produite lors de la modification: {str(e)}"
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    async def _process_config_change(self, guild_config, module: str, setting: str, value: str, interaction: discord.Interaction) -> bool:
        """Traite le changement de configuration"""
        
        # Conversion des valeurs booléennes
        bool_value = value.lower() in ['true', '1', 'on', 'yes', 'oui', 'activé']
        
        if module == "moderation":
            if setting == "enabled":
                guild_config.moderation_enabled = bool_value
                return True
            elif setting == "muted_role":
                # Recherche du rôle
                role = discord.utils.get(interaction.guild.roles, name=value) or \
                       discord.utils.get(interaction.guild.roles, id=int(value.strip('<@&>'))) if value.startswith('<@&') else None
                if role:
                    guild_config.muted_role_id = role.id
                    return True
        
        elif module == "levels":
            if setting == "enabled":
                guild_config.levels_enabled = bool_value
                return True
        
        elif module == "economy":
            if setting == "enabled":
                guild_config.economy_enabled = bool_value
                return True
        
        elif module == "welcome":
            if setting == "enabled":
                guild_config.welcome_enabled = bool_value
                return True
            elif setting == "channel":
                # Recherche du canal
                channel = discord.utils.get(interaction.guild.channels, name=value.strip('#')) or \
                         discord.utils.get(interaction.guild.channels, id=int(value.strip('<#>'))) if value.startswith('<#') else None
                if channel:
                    guild_config.welcome_channel_id = channel.id
                    return True
        
        elif module == "logs":
            if setting == "enabled":
                guild_config.logs_enabled = bool_value
                return True
            elif setting == "channel":
                # Recherche du canal
                channel = discord.utils.get(interaction.guild.channels, name=value.strip('#')) or \
                         discord.utils.get(interaction.guild.channels, id=int(value.strip('<#>'))) if value.startswith('<#') else None
                if channel:
                    guild_config.logs_channel_id = channel.id
                    return True
        
        return False
    
    async def _reset_config(self, interaction: discord.Interaction, guild_id: int, module: Optional[str]):
        """Remet à zéro la configuration"""
        
        try:
            guild_config = await self.bot.db.get_guild(guild_id)
            if not guild_config:
                embed = EmbedBuilder.error(
                    "Erreur",
                    "Aucune configuration trouvée pour ce serveur."
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            if module:
                # Reset d'un module spécifique
                if module == "moderation":
                    guild_config.moderation_enabled = True
                    guild_config.moderator_role_id = None
                    guild_config.muted_role_id = None
                elif module == "welcome":
                    guild_config.welcome_enabled = False
                    guild_config.welcome_channel_id = None
                elif module == "logs":
                    guild_config.logs_enabled = False
                    guild_config.logs_channel_id = None
                
                message = f"Configuration du module **{module}** réinitialisée."
            else:
                # Reset complet
                guild_config.moderation_enabled = True
                guild_config.levels_enabled = True
                guild_config.economy_enabled = True
                guild_config.welcome_enabled = False
                guild_config.logs_enabled = False
                guild_config.welcome_channel_id = None
                guild_config.logs_channel_id = None
                guild_config.moderator_role_id = None
                guild_config.muted_role_id = None
                
                message = "Configuration complète réinitialisée."
            
            # Sauvegarde
            async with self.bot.db.get_session() as session:
                session.add(guild_config)
                await session.commit()
            
            embed = EmbedBuilder.success("Configuration réinitialisée", message)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
        except Exception as e:
            embed = EmbedBuilder.error(
                "Erreur",
                f"Une erreur s'est produite lors de la réinitialisation: {str(e)}"
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)

async def setup(bot):
    """Fonction de setup pour charger le cog"""
    await bot.add_cog(ConfigCog(bot))

